local AL = LibStub("AceLocale-3.0"):GetLocale("AtlasLoot");
local BabbleInventory = AtlasLoot_GetLocaleLibBabble("LibBabble-Inventory-3.0")
local BabbleFaction = AtlasLoot_GetLocaleLibBabble("LibBabble-Faction-3.0")
local BabbleZone = AtlasLoot_GetLocaleLibBabble("LibBabble-Zone-3.0")





	AtlasLoot_Data["CUSTOMMENU"] = {
		{ 1, "CUSTOMFACTIONMENU", "achievement_reputation_01", "=ds="..AL["Factions"], ""};
		{ 2, "CUSTOMCURRENCYMENU", "inv_misc_coin_16", "=ds="..AL["Currencies"], ""};		
		{ 3, "CUSTOMSETMENU", "INV_Helmet_15", "=ds="..AL["Sets"], ""};		
	};

	AtlasLoot_Data["CUSTOMFACTIONMENU"] = {
		{ 2, "MagramClan", "INV_Misc_Head_Centaur_01", "=ds="..BabbleFaction["Magram Clan Centaur"], "=q5="..BabbleZone["Desolace"]};
		{ 3, "GelkisClan", "INV_Misc_Head_Centaur_01", "=ds="..BabbleFaction["Gelkis Clan Centaur"], "=q5="..BabbleZone["Desolace"]};
		Back = "CUSTOMMENU";
	};
	
	AtlasLoot_Data["CUSTOMCURRENCYMENU"] = {
		{ 2, "GangCard", "inv_misc_ticket_tarot_furies", "=ds=Gang Card", ""};
		{ 3, "EnigmaticToken", "spell_ice_rune", "=ds=Enigmatic Token", ""};
		Back = "CUSTOMMENU";
	};
	
	AtlasLoot_Data["CUSTOMSETMENU"] = {
		{ 2, "ZGPaladin", "inv_jewelry_necklace_26", "=ds=ZG Paladin", ""};
		{ 3, "MCPaladin", "inv_helmet_05", "=ds=MC Paladin", ""};
		Back = "CUSTOMMENU";
	};
	